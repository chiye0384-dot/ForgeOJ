#!/usr/bin/env bash
set -euo pipefail
for w in 1 2 3; do
 (for n in $(seq 1 100); do
 f=$(mktemp /output/record-XXXXXXXXXX.json)
 printf '{"worker":%s,"index":%s}\n' "$w" "$n" > "$f"
 done) &
done
wait
