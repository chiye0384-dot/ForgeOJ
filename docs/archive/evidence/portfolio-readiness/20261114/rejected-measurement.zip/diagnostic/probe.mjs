import {appendFile,writeFile} from "node:fs/promises";
let queue=Promise.resolve();
for(const mode of ["concurrent","serialized"]){
 await writeFile(`/output/${mode}.ndjson`,"");
 await Promise.all(Array.from({length:3},(_,w)=>(async()=>{for(let n=0;n<100;n++){
 const row=JSON.stringify({worker:w,index:n,payload:"x".repeat(200)})+"\n";
 if(mode==="concurrent")await appendFile(`/output/${mode}.ndjson`,row);
 else {queue=queue.then(()=>appendFile(`/output/${mode}.ndjson`,row));await queue;}
 }})()));
}
